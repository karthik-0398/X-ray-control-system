function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S1>/DAC resolution * Filament current */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:34"] = "Digital_x_ray_control_system.vhd:1853,1854,1855,1856,1857,1858,1859,1860";
	/* <S1>/Data Type Conversion */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:228"] = "Digital_x_ray_control_system.vhd:1374,1375,1376,1377,1378,1379,1380";
	/* <S1>/Dead Zone */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:128"] = "Digital_x_ray_control_system.vhd:1994,1995";
	/* <S1>/Delay */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:235"] = "Digital_x_ray_control_system.vhd:4903,4904,4905,4906,4907,4908,4909,4910,4911,4912,4913,4915";
	/* <S1>/Delay1 */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:236"] = "Digital_x_ray_control_system.vhd:1925,1926,1927,1928,1929,1930,1931,1932,1933,1934,1935,1937";
	/* <S1>/Delta filament */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:36"] = "Digital_x_ray_control_system.vhd:1822,1823,1824,1825,1826,1827,1828,1829";
	/* <S1>/Derivative subtract */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:233"] = "Digital_x_ray_control_system.vhd:1916,1917,1918,1919,1920,1921,1922,1923";
	/* <S1>/Discrete
Transfer Fcn */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:182"] = "Digital_x_ray_control_system.vhd:1907,1908,1909,1910,1911,1912,1913,1914";
	/* <S1>/Error */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:6"] = "Digital_x_ray_control_system.vhd:1382,1383,1384,1385,1386,1387,1388,1389";
	/* <S1>/Filament Preheats 
(Tube_curr_ref vs Tube_kV_ref) */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:130"] = "Digital_x_ray_control_system.vhd:1437,1438,1439,1440,1443,1444,1445,1446,1447,1450,1451,1452,1453,1454,1455,1456,1457,1460,1461,1462,1463,1464,1465,1466,1469,1470,1471,1472,1473,1474,1475,1476,1479,1480,1481,1482,1483,1484,1485,1486,1489,1490,1491,1492,1493,1494,1495,1496,1499,1500,1501,1502,1503,1504,1505,1506,1509,1510,1511,1512,1513,1514,1515,1516,1519,1520,1521,1522,1523,1524,1525,1526,1529,1530,1531,1532,1533,1534,1535,1538,1539,1540,1541,1542,1543,1544,1547,1548,1549,1550,1551,1552,1553,1554,1557,1558,1559,1560,1561,1562,1563,1564,1567,1568,1569,1570,1571,1572,1573,1574,1577,1578,1579,1580,1581,1582,1583,1584,1587,1588,1589,1590,1591,1592,1593,1594,1597,1598,1599,1600,1601,1602,1603,1604,1607,1608,1609,1610,1611,1612,1613,1614,1617,1618,1619,1620,1621,1622,1623,1624,1627,1628,1629,1630,1631,1632,1633,1634,2036,2043,2046,2050,2051,2054,2055,2059,2060,2064,2065,2069,2070,2074,2075,2079,2080,2084,2085,2089,2090,2094,2095,2099,2100,2104,2105,2109,2110,2114,2115,2119,2120,2124,2125,2129,2130,2134,2135,2139,2140,2144,2145,2149,2150,2154,2155,2159,2160,2164,2165,2169,2170,2174,2175,2179,2180,2184,2185,2189,2190,2194,2195,2199,2200,2204,2205,2209,2210,2214,2215,2219,2220,2224,2225,2229,2230,2234,2235,2239,2240,2244,2245,2249,2250,2254,2255,2259,2260,2264,2265,2269,2270,2274,2275,2279,2280,2284,2285,2289,2290,2294,2295,2299,2300,2304,2305,2309,2310,2314,2315,2319,2320,2324,2325,2329,2330,2334,2335,2339,2340,2344,2345,2349,2350,2354,2355,2359,2360,2364,2365,2369,2370,2374,2375,2376,2380,2381,2384,2385,2386,2389,2393,2394,2397,2398,2399,2403,2404,2407,2408,2409,2412,2415,2419,2420,2423,2424,2425,2429,2430,2433,2434,2435,2438,2442,2443,2446,2447,2448,2452,2453,2456,2457,2458,2461,2464,2467,2471,2472,2475,2476,2477,2481,2482,2485,2486,2487,2490,2494,2495,2498,2499,2500,2504,2505,2508,2509,2510,2513,2516,2520,2521,2524,2525,2526,2530,2531,2534,2535,2536,2539,2543,2544,2547,2548,2549,2553,2554,2557,2558,2559,2562,2565,2568,2571,2575,2576,2579,2580,2581,2585,2586,2589,2590,2591,2594,2598,2599,2602,2603,2604,2608,2609,2612,2613,2614,2617,2620,2624,2625,2628,2629,2630,2634,2635,2638,2639,2640,2643,2647,2648,2651,2652,2653,2657,2658,2661,2662,2663,2666,2669,2672,2676,2677,2680,2681,2682,2686,2687,2690,2691,2692,2695,2699,2700,2703,2704,2705,2709,2710,2713,2714,2715,2718,2721,2725,2726,2729,2730,2731,2735,2736,2739,2740,2741,2744,2748,2749,2752,2753,2754,2758,2759,2762,2763,2764,2767,2770,2773,2776,2779,2783,2784,2787,2788,2789,2793,2794,2797,2798,2799,2802,2806,2807,2810,2811,2812,2816,2817,2820,2821,2822,2825,2828,2832,2833,2836,2837,2838,2842,2843,2846,2847,2848,2851,2855,2856,2859,2860,2861,2865,2866,2869,2870,2871,2874,2877,2880,2884,2885,2888,2889,2890,2894,2895,2898,2899,2900,2903,2907,2908,2911,2912,2913,2917,2918,2921,2922,2923,2926,2929,2933,2934,2937,2938,2939,2943,2944,2947,2948,2949,2952,2956,2957,2960,2961,2962,2966,2967,2970,2971,2972,2975,2978,2981,2984,2988,2989,2992,2993,2994,2998,2999,3002,3003,3004,3007,3011,3012,3015,3016,3017,3021,3022,3025,3026,3027,3030,3033,3037,3038,3041,3042,3043,3047,3048,3051,3052,3053,3056,3060,3061,3064,3065,3066,3070,3071,3074,3075,3076,3079,3082,3085,3089,3090,3093,3094,3095,3099,3100,3103,3104,3105,3108,3112,3113,3116,3117,3118,3122,3123,3126,3127,3128,3131,3134,3137,3140,3143,3146,3149,3153,3154,3175,3182,3185,3189,3190,3193,3194,3198,3199,3203,3204,3208,3209,3213,3214,3218,3219,3223,3224,3228,3229,3233,3234,3238,3239,3243,3244,3248,3249,3253,3254,3255,3259,3260,3263,3264,3265,3268,3272,3273,3276,3277,3278,3282,3283,3286,3287,3288,3291,3294,3298,3299,3302,3303,3304,3308,3309,3312,3313,3314,3317,3321,3322,3325,3326,3327,3331,3332,3335,3336,3337,3340,3343,3346,3350,3351,3354,3357,3360,3363,3366,3369,3373,3374,3391,3392,3395,3396,3425,3456,3487,3490,3491,3534,3565&DirectLUTSubNetwork.vhd:326,327,328,329,330,331,332";
	/* <S1>/Filament Preheats 
(Tube_curr_ref vs Tube_kV_ref) delta */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:131"] = "Digital_x_ray_control_system.vhd:1645,1646,1647,1648,1650,1651,1652,1653,1655,1656,1657,1658,1659,1660,1661,1663,1664,1665,1666,1667,1668,1669,1671,1672,1673,1674,1675,1676,1677,1678,1680,1681,1682,1683,1684,1685,1686,1687,1689,1690,1691,1692,1693,1694,1695,1696,1698,1699,1700,1701,1702,1703,1704,1705,1707,1708,1709,1710,1711,1712,1713,1714,1716,1717,1718,1719,1720,1721,1722,1723,1725,1726,1727,1728,1729,1730,1731,1733,1734,1735,1736,1737,1738,1739,1741,1742,1743,1744,1745,1746,1747,1748,1750,1751,1752,1753,1754,1755,1756,1757,1759,1760,1761,1762,1763,1764,1765,1766,1768,1769,1770,1771,1772,1773,1774,1775,1777,1778,1779,1780,1781,1782,1783,1784,1786,1787,1788,1789,1790,1791,1792,1793,1795,1796,1797,1798,1799,1800,1801,1802,1804,1805,1806,1807,1808,1809,1810,1811,1813,1814,1815,1816,1817,1818,1819,1820,3621,3627,3629,3632,3633,3635,3636,3639,3640,3643,3644,3647,3648,3651,3652,3655,3656,3659,3660,3663,3664,3667,3668,3671,3672,3675,3676,3679,3680,3683,3684,3687,3688,3691,3692,3695,3696,3699,3700,3703,3704,3707,3708,3711,3712,3715,3716,3719,3720,3723,3724,3727,3728,3731,3732,3735,3736,3739,3740,3743,3744,3747,3748,3751,3752,3755,3756,3759,3760,3763,3764,3767,3768,3771,3772,3775,3776,3779,3780,3783,3784,3787,3788,3791,3792,3795,3796,3799,3800,3803,3804,3807,3808,3811,3812,3815,3816,3819,3820,3823,3824,3827,3828,3831,3832,3835,3836,3839,3840,3843,3844,3847,3848,3851,3852,3855,3856,3859,3860,3863,3864,3867,3868,3871,3872,3875,3876,3879,3880,3883,3884,3887,3888,3891,3892,3893,3896,3897,3899,3900,3901,3903,3906,3907,3909,3910,3911,3914,3915,3917,3918,3919,3921,3923,3926,3927,3929,3930,3931,3934,3935,3937,3938,3939,3941,3944,3945,3947,3948,3949,3952,3953,3955,3956,3957,3959,3961,3963,3966,3967,3969,3970,3971,3974,3975,3977,3978,3979,3981,3984,3985,3987,3988,3989,3992,3993,3995,3996,3997,3999,4001,4004,4005,4007,4008,4009,4012,4013,4015,4016,4017,4019,4022,4023,4025,4026,4027,4030,4031,4033,4034,4035,4037,4039,4041,4043,4046,4047,4049,4050,4051,4054,4055,4057,4058,4059,4061,4064,4065,4067,4068,4069,4072,4073,4075,4076,4077,4079,4081,4084,4085,4087,4088,4089,4092,4093,4095,4096,4097,4099,4102,4103,4105,4106,4107,4110,4111,4113,4114,4115,4117,4119,4121,4124,4125,4127,4128,4129,4132,4133,4135,4136,4137,4139,4142,4143,4145,4146,4147,4150,4151,4153,4154,4155,4157,4159,4162,4163,4165,4166,4167,4170,4171,4173,4174,4175,4177,4180,4181,4183,4184,4185,4188,4189,4191,4192,4193,4195,4197,4199,4201,4203,4206,4207,4209,4210,4211,4214,4215,4217,4218,4219,4221,4224,4225,4227,4228,4229,4232,4233,4235,4236,4237,4239,4241,4244,4245,4247,4248,4249,4252,4253,4255,4256,4257,4259,4262,4263,4265,4266,4267,4270,4271,4273,4274,4275,4277,4279,4281,4284,4285,4287,4288,4289,4292,4293,4295,4296,4297,4299,4302,4303,4305,4306,4307,4310,4311,4313,4314,4315,4317,4319,4322,4323,4325,4326,4327,4330,4331,4333,4334,4335,4337,4340,4341,4343,4344,4345,4348,4349,4351,4352,4353,4355,4357,4359,4361,4364,4365,4367,4368,4369,4372,4373,4375,4376,4377,4379,4382,4383,4385,4386,4387,4390,4391,4393,4394,4395,4397,4399,4402,4403,4405,4406,4407,4410,4411,4413,4414,4415,4417,4420,4421,4423,4424,4425,4428,4429,4431,4432,4433,4435,4437,4439,4442,4443,4445,4446,4447,4450,4451,4453,4454,4455,4457,4460,4461,4463,4464,4465,4468,4469,4471,4472,4473,4475,4477,4479,4481,4483,4485,4487,4490,4491,4509,4515,4517,4520,4521,4523,4524,4527,4528,4531,4532,4535,4536,4539,4540,4543,4544,4547,4548,4551,4552,4555,4556,4559,4560,4563,4564,4567,4568,4571,4572,4573,4576,4577,4579,4580,4581,4583,4586,4587,4589,4590,4591,4594,4595,4597,4598,4599,4601,4603,4606,4607,4609,4610,4611,4614,4615,4617,4618,4619,4621,4624,4625,4627,4628,4629,4632,4633,4635,4636,4637,4639,4641,4643,4646,4647,4649,4651,4653,4655,4657,4659,4662,4663,4679,4681,4682,4710,4740,4770,4772,4773,4815,4845&DirectLUTSubNetwork_block.vhd:325,326,327,328";
	/* <S1>/Gain add */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:232"] = "Digital_x_ray_control_system.vhd:1862,1863,1864,1865,1866,1867,1868,1869";
	/* <S1>/Multiplocation factor 0.4 */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:40"] = "Digital_x_ray_control_system.vhd:2011";
	/* <S1>/Multiplying factor 5mA */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:19"] = "Digital_x_ray_control_system.vhd:3617";
	/* <S1>/Multiplying factor DAC resolution */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:35"] = "Digital_x_ray_control_system.vhd:4933";
	/* <S1>/Multiplying factor mA -> A */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:4"] = "Digital_x_ray_control_system.vhd:2031";
	/* <S1>/Product 1 */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:5"] = "Digital_x_ray_control_system.vhd:1427,1428,1429,1430,1431,1432,1433,1434";
	/* <S1>/Product 5 */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:39"] = "Digital_x_ray_control_system.vhd:1832,1833,1834,1835,1836,1837,1838,1839";
	/* <S1>/Product 6 */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:41"] = "Digital_x_ray_control_system.vhd:1842,1843,1844,1845,1846,1847,1848,1849";
	/* <S1>/Rate Transition */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:229"] = "Digital_x_ray_control_system.vhd:4937";
	/* <S1>/Rate Transition1 */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:230"] = "Digital_x_ray_control_system.vhd:1374,1375,1376,1377,1378,1379,1380";
	/* <S1>/Rate Transition2 */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:231"] = "Digital_x_ray_control_system.vhd:1374,1375,1376,1377,1378,1379,1380";
	/* <S1>/Tube ref - 5mA */
	this.urlHashMap["X_Ray_Control_System_stable_with_deadzone:18"] = "Digital_x_ray_control_system.vhd:1636,1637,1638,1639,1640,1641,1642,1643";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "X_Ray_Control_System_stable_with_deadzone"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>/In1"] = {sid: "X_Ray_Control_System_stable_with_deadzone:164"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:164"] = {rtwname: "<S1>/In1"};
	this.rtwnameHashMap["<S1>/In2"] = {sid: "X_Ray_Control_System_stable_with_deadzone:165"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:165"] = {rtwname: "<S1>/In2"};
	this.rtwnameHashMap["<S1>/In3"] = {sid: "X_Ray_Control_System_stable_with_deadzone:166"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:166"] = {rtwname: "<S1>/In3"};
	this.rtwnameHashMap["<S1>/In4"] = {sid: "X_Ray_Control_System_stable_with_deadzone:167"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:167"] = {rtwname: "<S1>/In4"};
	this.rtwnameHashMap["<S1>/In5"] = {sid: "X_Ray_Control_System_stable_with_deadzone:168"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:168"] = {rtwname: "<S1>/In5"};
	this.rtwnameHashMap["<S1>/DAC resolution * Filament current"] = {sid: "X_Ray_Control_System_stable_with_deadzone:34"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:34"] = {rtwname: "<S1>/DAC resolution * Filament current"};
	this.rtwnameHashMap["<S1>/Data Type Conversion"] = {sid: "X_Ray_Control_System_stable_with_deadzone:228"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:228"] = {rtwname: "<S1>/Data Type Conversion"};
	this.rtwnameHashMap["<S1>/Dead Zone"] = {sid: "X_Ray_Control_System_stable_with_deadzone:128"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:128"] = {rtwname: "<S1>/Dead Zone"};
	this.rtwnameHashMap["<S1>/Delay"] = {sid: "X_Ray_Control_System_stable_with_deadzone:235"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:235"] = {rtwname: "<S1>/Delay"};
	this.rtwnameHashMap["<S1>/Delay1"] = {sid: "X_Ray_Control_System_stable_with_deadzone:236"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:236"] = {rtwname: "<S1>/Delay1"};
	this.rtwnameHashMap["<S1>/Delta filament"] = {sid: "X_Ray_Control_System_stable_with_deadzone:36"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:36"] = {rtwname: "<S1>/Delta filament"};
	this.rtwnameHashMap["<S1>/Derivative subtract"] = {sid: "X_Ray_Control_System_stable_with_deadzone:233"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:233"] = {rtwname: "<S1>/Derivative subtract"};
	this.rtwnameHashMap["<S1>/Discrete Transfer Fcn"] = {sid: "X_Ray_Control_System_stable_with_deadzone:182"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:182"] = {rtwname: "<S1>/Discrete Transfer Fcn"};
	this.rtwnameHashMap["<S1>/Error"] = {sid: "X_Ray_Control_System_stable_with_deadzone:6"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:6"] = {rtwname: "<S1>/Error"};
	this.rtwnameHashMap["<S1>/Filament Preheats  (Tube_curr_ref vs Tube_kV_ref)"] = {sid: "X_Ray_Control_System_stable_with_deadzone:130"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:130"] = {rtwname: "<S1>/Filament Preheats  (Tube_curr_ref vs Tube_kV_ref)"};
	this.rtwnameHashMap["<S1>/Filament Preheats  (Tube_curr_ref vs Tube_kV_ref) delta"] = {sid: "X_Ray_Control_System_stable_with_deadzone:131"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:131"] = {rtwname: "<S1>/Filament Preheats  (Tube_curr_ref vs Tube_kV_ref) delta"};
	this.rtwnameHashMap["<S1>/Gain add"] = {sid: "X_Ray_Control_System_stable_with_deadzone:232"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:232"] = {rtwname: "<S1>/Gain add"};
	this.rtwnameHashMap["<S1>/Multiplocation factor 0.4"] = {sid: "X_Ray_Control_System_stable_with_deadzone:40"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:40"] = {rtwname: "<S1>/Multiplocation factor 0.4"};
	this.rtwnameHashMap["<S1>/Multiplying factor 5mA"] = {sid: "X_Ray_Control_System_stable_with_deadzone:19"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:19"] = {rtwname: "<S1>/Multiplying factor 5mA"};
	this.rtwnameHashMap["<S1>/Multiplying factor DAC resolution"] = {sid: "X_Ray_Control_System_stable_with_deadzone:35"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:35"] = {rtwname: "<S1>/Multiplying factor DAC resolution"};
	this.rtwnameHashMap["<S1>/Multiplying factor mA -> A"] = {sid: "X_Ray_Control_System_stable_with_deadzone:4"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:4"] = {rtwname: "<S1>/Multiplying factor mA -> A"};
	this.rtwnameHashMap["<S1>/Product 1"] = {sid: "X_Ray_Control_System_stable_with_deadzone:5"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:5"] = {rtwname: "<S1>/Product 1"};
	this.rtwnameHashMap["<S1>/Product 5"] = {sid: "X_Ray_Control_System_stable_with_deadzone:39"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:39"] = {rtwname: "<S1>/Product 5"};
	this.rtwnameHashMap["<S1>/Product 6"] = {sid: "X_Ray_Control_System_stable_with_deadzone:41"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:41"] = {rtwname: "<S1>/Product 6"};
	this.rtwnameHashMap["<S1>/Rate Transition"] = {sid: "X_Ray_Control_System_stable_with_deadzone:229"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:229"] = {rtwname: "<S1>/Rate Transition"};
	this.rtwnameHashMap["<S1>/Rate Transition1"] = {sid: "X_Ray_Control_System_stable_with_deadzone:230"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:230"] = {rtwname: "<S1>/Rate Transition1"};
	this.rtwnameHashMap["<S1>/Rate Transition2"] = {sid: "X_Ray_Control_System_stable_with_deadzone:231"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:231"] = {rtwname: "<S1>/Rate Transition2"};
	this.rtwnameHashMap["<S1>/Tube ref - 5mA"] = {sid: "X_Ray_Control_System_stable_with_deadzone:18"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:18"] = {rtwname: "<S1>/Tube ref - 5mA"};
	this.rtwnameHashMap["<S1>/Out1"] = {sid: "X_Ray_Control_System_stable_with_deadzone:169"};
	this.sidHashMap["X_Ray_Control_System_stable_with_deadzone:169"] = {rtwname: "<S1>/Out1"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
